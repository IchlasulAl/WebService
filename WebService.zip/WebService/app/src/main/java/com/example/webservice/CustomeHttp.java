package com.example.webservice;

public class CustomeHttp {
}
